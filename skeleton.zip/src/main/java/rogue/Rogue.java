package rogue;

import java.util.ArrayList;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.awt.Point;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class Rogue{

    public setPlayer(Player thePlayer){

    }


    public void setSymbols(String filename){

    }

    public ArrayList<Room> getRooms(){

    }

    public ArrayList<Item> getItems(){

    }
    public Player getPlayer(){

    }

    public void createRooms(String filename){

    }
    public String displayAll(){
        //creates a string that displays all the rooms in the dungeon
    }
}