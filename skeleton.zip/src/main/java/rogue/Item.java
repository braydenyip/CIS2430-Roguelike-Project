package rogue;
import java.awt.Point;

/**
 * A basic Item class; basic functionality for both consumables and equipment
 */
public class Item  {



    //Constructors
    public Item() {
        
    }

    public Item(int id, String name, String type, Point xyLocation) {

    }
    
    // Getters and setters


    public int getId() {
       
    }


    public void setId(int id) {

    }


    public String getName() {

    }


    public void setName(String name) {

    }


    public String getType() {

    }


    public void setType(String type) {

    }
    

    public Character getDisplayCharacter() {
        
    }


    public void setDisplayCharacter(Character newDisplayCharacter) {
        
    }


    public String getDescription() {
     
    }


    public void setDescription(String newDescription) {
     
    }


    public Point getXyLocation() {
     
    }

    
    public void setXyLocation(Point newXyLocation) {
        
    }


    public Room getCurrentRoom() {
        
    }


    public void setCurrentRoom(Room newCurrentRoom) {
        
    }
}
