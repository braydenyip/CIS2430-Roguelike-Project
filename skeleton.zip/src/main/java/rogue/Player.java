package rogue;
import java.util.ArrayList;
import java.awt.Point;
/**
 * The player character
 */
public class Player {



    // Default constructor
    public Player() {

    }


    public Player(String name) {

    }


    public String getName() {

    }


    public void setName(String newName) {

    }

    public Point getXyLocation() {

    }


    public void setName(Point newXyLocation) {

    }


    public Room getCurrentRoom() {

    }


    public void setCurrentRoom(Room newRoom) {

    }
}
